<?php
$host = "localhost";
$username = "uifkmajb0snq8";
$password = "Za_021646";
$database = "dbouwzy0ugogyg";

?>