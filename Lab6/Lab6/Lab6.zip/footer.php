
<?php
$firstName="Zahi";
$lastName="Masarwa";
$studentNumber="040985420";
$email="masa0019@algonquinlive.com";
    echo "<div id=\"footer\">First Name: $firstName</br>
    Last Name: $lastName</br>
    Student Number: $studentNumber</br>
    Email: $email
    </div>";
?>  