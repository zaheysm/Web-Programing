<?php
echo "<div id=\"Menu\">
<a href=\"All.php\">All</a>
<a href=\"Ten.php\">Ten</a>
<a href=\"EvenOdd.php \">EvenOdd</a>
<a href=\"Random.php \">Random</a>
<a href=\"Pattern.php \">Pattern</a>
</div>"
?>