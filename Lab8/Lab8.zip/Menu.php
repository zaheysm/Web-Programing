<?php
echo "<div id=\"Menu\">
<a href=\"Input.php\">Input</a>
<a href=\"Session1.php\">Session 1</a>
<a href=\"Session2.php\">Session 2</a>
</div>"
?>