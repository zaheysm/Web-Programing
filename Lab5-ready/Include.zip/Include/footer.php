<?php
	echo "<div id=\"footer\">My footer goes here :)</div>";
?>