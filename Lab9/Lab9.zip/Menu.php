<?php
echo "<div id=\"Menu\">
<a href=\"CreateAccount.php\">Create Account</a>
<a href=\"Login.php\">Login</a>
<a href=\"ViewAllEmployees.php\">View All Employees</a>
</div>"
?>