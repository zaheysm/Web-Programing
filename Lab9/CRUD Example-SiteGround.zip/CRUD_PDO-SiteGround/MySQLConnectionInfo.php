<?php
$host = "localhost";
$username = "usrcy5znrdgvp";
$password = "cst@8238";
$database = "dbuy9cgemdwqa3";
?>