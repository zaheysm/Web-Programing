<?php
$host = "localhost";
$username = "cst8238";
$password = "cst@8238";
$database = "cst8238";
?>