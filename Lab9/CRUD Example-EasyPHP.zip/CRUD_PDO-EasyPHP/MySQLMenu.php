<?php
	echo "<a href=\"MySQLInsert.php\">INSERT Page</a> | <a href=\"MySQLSelect.php\">SELECT Page</a><br /><br />";
?>