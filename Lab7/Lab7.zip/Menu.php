<?php
echo "<div id=\"Menu\">
<a href=\"Arrays.php\">Arrays</a>
<a href=\"Calculator.php\">Calculator</a>
<a href=\"Objects.php\">Objects</a>
</div>"
?>